// replace every normal function with: 

const varName = function(){} 
/*
    CIT 281 Project 2
    Name: Margarita Duran-Espino
*/

// Returns a random number between min (inclusive) and max (exclusive)
//rewrite
const getRandomInteger = function (min, max) {
    return Math.floor(Math.random() * (max - min) + min); }  
    const alphabet = "abcdefghijklmnopqrstuvwxyz".split(""); 
    let result = "";  for (let i = 0; i < getRandomInteger(5, 26); i++) {     
        result += alphabet[getRandomInteger(1,alphabet.length-1)]; 
    }
    console.log(result);

//new getRandomLetter() *calls for one single random character
//rewrite
const getRandomLetter = function (min, max) {
    return Math.floor(Math.random() * (max - min) + min);}
    const alphabet ="abcdefghijklmnopqrstuvwxyz".split("");
    let result = ""; 
    for (let i = 0; i < getRandomLetter(1,1); i++) {
        result += alphabet[getRandomLetter(1,alphabet.length-1)];
    }
    console.log(result);

//new getRandomString(minLength, maxLength) *calls for random length string
//rewrite
const getRandomString = function (min, max) {
    return Math.floor(Math.random() * (max - min) + min); }  
    const alphabet = "abcdefghijklmnopqrstuvwxyz".split(""); 
    let result = "";  for (let i = 0; i < getRandomString(10, 20); i++) {     
        result += alphabet[getRandomString(1,alphabet.length-1)]; 
    }
    console.log(result);

//new final function which will return the string in ascending order
//rewrite
const string = ["Eenie", "Meenie", "Winey", "Fo"]; string.sort();
console.log(string);